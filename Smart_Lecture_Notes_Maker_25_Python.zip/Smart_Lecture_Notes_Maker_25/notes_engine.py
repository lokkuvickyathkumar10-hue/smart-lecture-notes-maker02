import re
from collections import Counter

STOP = set("""the a an and or but if then is are was were be been being to of in on for with as by from at this that these those it its into about than their they them we you your i he she""".split())

def sentences(text):
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text.strip()) if len(s.strip()) > 20]

def keywords(text, limit=12):
    words = re.findall(r"\b[A-Za-z][A-Za-z0-9_-]{3,}\b", text.lower())
    counts = Counter(w for w in words if w not in STOP)
    return [w for w,_ in counts.most_common(limit)]

def generate_notes(content, title="", subject=""):
    sents = sentences(content)
    terms = keywords(content)
    lines = [f"# {title or 'Lecture Notes'}", ""]
    if subject: lines += [f"**Subject:** {subject}", ""]
    lines += ["## Overview", (sents[0] if sents else content[:400]), "", "## Main Topics"]
    if terms:
        for term in terms[:8]:
            lines.append(f"- **{term.title()}**")
    else:
        lines.append("- Review the lecture content and identify its central ideas.")
    lines += ["", "## Important Points"]
    for s in sents[:12]:
        lines.append(f"- {s}")
    if not sents:
        lines.append(f"- {content.strip()[:1000]}")
    lines += ["", "## Key Terms"]
    for term in terms[:10]:
        lines.append(f"- **{term.title()}** — A key term mentioned in the lecture; review its meaning in context.")
    if not terms: lines.append("- Add or identify important subject-specific vocabulary.")
    lines += ["", "## Short Summary"]
    summary = " ".join(sents[:3]) if sents else content.strip()[:500]
    lines += [summary, "", "## Revision Questions"]
    for i, term in enumerate(terms[:6], 1):
        lines.append(f"{i}. Explain **{term}** and describe its importance in this lecture.")
    if not terms:
        lines += ["1. What is the main idea of this lecture?", "2. List three important points."]
    lines += ["", "> Tip: These notes are automatically organized from your supplied text. Check definitions and details against your class material."]
    return "\n".join(lines)

def make_quiz(content, count=5):
    sents = sentences(content)
    terms = keywords(content, max(count, 10))
    quiz = []
    for i, term in enumerate(terms[:count]):
        context = next((s for s in sents if term in s.lower()), "")
        if not context:
            continue
        question = f"Which keyword appears in this lecture statement: “{context[:150]}”?"
        distractors = [x for x in terms if x != term][:3]
        options = [term] + distractors
        # Stable ordering with answer first; radio quiz checks exact answer.
        quiz.append({"question": question, "options": options, "answer": term})
    return quiz
