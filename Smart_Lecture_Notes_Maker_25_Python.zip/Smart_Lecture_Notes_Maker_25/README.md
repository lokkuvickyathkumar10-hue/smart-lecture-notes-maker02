# Smart Lecture Notes Maker 25

A Streamlit + Python application for turning lecture text into organized revision notes and quizzes.

## Run locally

1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Create a GitHub repository and upload all files in this folder.
2. Sign in to Streamlit Community Cloud.
3. Choose **Create app**, select your repository, and set the main file to `app.py`.
4. Deploy.

## Optional audio transcription

Audio transcription uses the OpenAI API. Add this in Streamlit Cloud app settings → Secrets:

```toml
OPENAI_API_KEY = "your-api-key"
```

Keep your API key private. Do not commit it to GitHub.

## Notes about generated content

The text notes and quiz generator use lightweight Python text processing. They organize the text you provide; they are not a substitute for checking technical definitions against your lecture material. Audio transcription is optional and requires the API key.
