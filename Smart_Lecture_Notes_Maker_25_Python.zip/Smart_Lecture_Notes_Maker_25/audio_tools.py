import os

def transcribe_audio(uploaded_file):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None, "Set OPENAI_API_KEY in your Streamlit Cloud Secrets to enable automatic transcription. You can still paste a transcript manually."
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        uploaded_file.seek(0)
        result = client.audio.transcriptions.create(
            model="gpt-4o-mini-transcribe",
            file=(uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type or "audio/mpeg")
        )
        return result.text, None
    except Exception as exc:
        return None, f"Transcription failed: {exc}"
